import os

folder_path = "."  # Run in current directory
output_list = []

for filename in sorted(os.listdir(folder_path)):
    if filename.endswith(".md"):
        with open(os.path.join(folder_path, filename), 'r') as f:
            for line in f:
                if line.startswith("# "):
                    output_list.append((filename, line.strip("# ").strip()))
                    break  # Only grab the first H1

# Print results
for i, (fname, h1) in enumerate(output_list, 1):
    print(f"{i:02}. {fname} — {h1}")